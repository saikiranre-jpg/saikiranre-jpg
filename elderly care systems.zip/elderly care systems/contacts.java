package com.example.clone2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class contacts extends AppCompatActivity {
    String text = "";
    private static final String FILE_NAME = "example.txt";

    private EditText num1;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        num1 = findViewById(R.id.c1);


       // Button img = (Button) findViewById(R.id.sav);

    }

    public void save(View v) {

        text+=num1.getText().toString(); text+=",";

        FileOutputStream fos =null;
        System.out.println(text);
        try {
            fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
            fos.write(text.getBytes());
            Toast.makeText(this,"Saved to" + getFilesDir() + "/" + FILE_NAME, Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos !=null){
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
        num1.getText().clear();
    }
    public void load(View v){
        Intent intent2 = new Intent(contacts.this, MainActivity.class);
        intent2.putExtra("key1",FILE_NAME);
        startActivity(intent2);
    }


}
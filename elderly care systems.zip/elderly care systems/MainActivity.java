package com.example.clone2;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    private static String FILE_NAME = "example.txt";
    private EditText mess;
    private ImageView send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mess = findViewById(R.id.message);
        mess.setText("I need help...");


        ImageView imgg=(ImageView)findViewById(R.id.cont);
        imgg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentc= new Intent(MainActivity.this,contacts.class);
                startActivity(intentc);
            }
        });

//        number = findViewById(R.id.number);
//        message = findViewById(R.id.message);
        send  = findViewById(R.id.send);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        sendSMS();
                    }else {
                        requestPermissions(new String[]{Manifest.permission.SEND_SMS},1);
                    }
                }

            }
        });
    }
    private void sendSMS(){
        String[] arr={"0","0","0","0","0","0","0"};
          FileInputStream fis = null;
       FILE_NAME = getIntent().getStringExtra ( "key1");
        try {
            fis = openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) !=null){
                sb.append(text).append("\n");
            }
             arr = sb.toString().split(",",6);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null){
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
//        String phoneNo[]={"0","0","0","0","0","0"};
//        for(int j=1;j<6;j++){
//            phoneNo[j]=getIntent().getStringExtra ( "key"+String.valueOf(j));
//        }
//        String phoneNo1 = getIntent().getStringExtra ( "key1");
//        String phoneNo2 = getIntent().getStringExtra ( "key2");
//        String phoneNo3 = getIntent().getStringExtra ( "key3");
//        String phoneNo4 = getIntent().getStringExtra ( "key4");
//        String phoneNo5 = getIntent().getStringExtra ( "key5");

        String SMS =mess.getText().toString().trim();
        for (int i=0;i<arr.length-1;i++)
            System.out.println(arr[i]);

        System.out.println(SMS);
        try
        {
            SmsManager smsManager = SmsManager.getDefault();

                for (int i=0;i<arr.length-1;i++)
                    smsManager.sendTextMessage(arr[i],null,SMS,null,null);
//                if (arr[1]!=null) smsManager.sendTextMessage(arr[1],null,SMS,null,null);
//                if (arr[2]!=null) smsManager.sendTextMessage(arr[2],null,SMS,null,null);
//                if (arr[3]!=null) smsManager.sendTextMessage(arr[3],null,SMS,null,null);
//                if (arr[4]!=null) smsManager.sendTextMessage(arr[4],null,SMS,null,null);

            Toast.makeText(this, "Message is sent", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
        }
    }

}

